
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Developed By:           Syed Yasser Arafat                           %
%                           MS(CS), 177 MS/CS/F04(CS)                    %
%                           IIU-Islamabad                                % 
%                           (International Islamic University)           %
%                           Pakistan                                     %
%                           mirpurian@gmail.com                          % 
%   Dated:                  April  2007                                  %
%                                                                        %
%   Thanks to: Mathworks.com and various  authors for their              %
%   various examples and tutorials regarding computer vision &           %
%   imageProcessing on internet                                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all
clear all
clc

% YTiler(2,2,'DSC00013.JPG');
YTiler(4,4,'DSC00013.JPG');
% YTiler(4,3,'DSC00013.JPG');