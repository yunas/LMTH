clc
nResults = 10
for i=1:2:nResults
     sprintf('Index = %d: ',i)
end